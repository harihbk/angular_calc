export const environment = {
  production: true,
  APIURL    : 'https://curtainmatrix.co.uk/api/public/api',
  Calendar_clientID : '421629888233-cdqm5rdeakdjvghies922jv0036tfcpj.apps.googleusercontent.com',
  Calendar_ClientSecret : '8rozNANkAYTYmRknYVJym9r4',
  CalendarAPIKEY        : 'AIzaSyCO1MXI1PEXjpTVoF3zFUR3i1-BjZ4pw4k',
  Redirect_url           : 'http://localhost:4200'

};
