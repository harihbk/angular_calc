import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customjob',
  templateUrl: './customjob.component.html',
  styleUrls: ['./customjob.component.css']
})
export class CustomjobComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
