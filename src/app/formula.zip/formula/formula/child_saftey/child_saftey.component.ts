import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child_saftey',
  templateUrl: './child_saftey.component.html',
  styleUrls: ['./child_saftey.component.css']
})
export class Child_safteyComponent implements OnInit {

  constructor() {

  }

  ngOnInit() {
  }

}
